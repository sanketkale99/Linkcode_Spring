package com.sunbase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculationApplicationTests {

	@Test
	void contextLoads() {
	}

}
