package com.sunbase.model;

public class Numbers {
    
	private int num1;
    private int num2;

    
	public int getNumber1() {
		return num1;
	}

	public void setNumber1(int number1) {
		this.num1 = number1;
	}

	public int getNumber2() {
		return num2;
	}

	public void setNumber2(int number2) {
		this.num2 = number2;
	}
        
}
